--@C:\BD_3IIR_PL_SQL\PL_SQL_ORACLE_2012\RAISE_ex1.sql
set echo on

spool C:\BD_3IIR_PL_SQL\PL_SQL_ORACLE_2012\tr_RAISE_ex1.txt

SET SERVEROUTPUT ON

--exemple VARRAY et initialisation

DECLARE
   IND_ZERO	EXCEPTION;
   IND 		NUMBER(2);	
BEGIN
  IND:=0;
  IF IND=0 THEN RAISE IND_ZERO;
  END IF;
  EXCEPTION
	WHEN IND_ZERO THEN DBMS_OUTPUT.PUT_LINE ('ERR: la valeur de l indice est erron�!!');
  DBMS_OUTPUT.PUT_LINE ('ERR CAPTUREE. LE PROGRAMME A CONTINUE!!');		
END;
/

spool off

